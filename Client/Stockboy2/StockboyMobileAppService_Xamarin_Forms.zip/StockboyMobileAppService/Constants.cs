﻿using System;

namespace StockboyMobileAppService
{
	public static class Constants
	{
		// Replace strings with your mobile services and gateway URLs.
		public static string ApplicationURL = @"https://stockboymobileappservice.azurewebsites.net";
	}
}

